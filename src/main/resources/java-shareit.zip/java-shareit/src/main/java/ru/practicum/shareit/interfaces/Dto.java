package ru.practicum.shareit.interfaces;

public interface Dto {
}
