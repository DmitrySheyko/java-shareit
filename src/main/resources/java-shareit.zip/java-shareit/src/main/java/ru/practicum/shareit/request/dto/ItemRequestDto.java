package ru.practicum.shareit.request.dto;

/**
 * TODO Sprint add-item-requests.
 */
public class ItemRequestDto {
}
